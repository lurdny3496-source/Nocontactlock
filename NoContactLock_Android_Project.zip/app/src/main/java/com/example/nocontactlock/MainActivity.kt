package com.example.nocontactlock
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.view.ViewGroup

class MainActivity : android.app.Activity() {
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val p = getSharedPreferences("guard",0)
  val phone = EditText(this); phone.hint="Numéro à protéger"
  phone.setText(p.getString("phone",""))
  val reason = EditText(this); reason.hint="Pourquoi ne veux-tu pas le contacter ?"; reason.minLines=3
  reason.setText(p.getString("reason",""))
  val save = Button(this); save.text="Enregistrer"
  val settings = Button(this); settings.text="Activer la protection Android"
  save.setOnClickListener { p.edit().putString("phone",phone.text.toString().filter{it.isDigit()}).putString("reason",reason.text.toString()).apply(); Toast.makeText(this,"Enregistré",Toast.LENGTH_SHORT).show() }
  settings.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
  val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(40,40,40,40)
  box.addView(phone); box.addView(reason); box.addView(save); box.addView(settings)
  setContentView(box)
 }
}