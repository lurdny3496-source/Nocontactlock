package com.example.nocontactlock
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class ContactGuardService: AccessibilityService() {
 private var overlay: View?=null
 override fun onAccessibilityEvent(e: AccessibilityEvent?) {
  if (e==null || e.packageName!="com.whatsapp") return
  val p=getSharedPreferences("guard",0)
  val target=p.getString("phone","") ?: return
  if(target.isBlank()) return
  val root=rootInActiveWindow ?: return
  val text=collect(root).replace(" ","").replace("+","")
  if(text.contains(target)) showGuard(p.getString("reason","") ?: "")
 }
 private fun collect(n: AccessibilityNodeInfo):String {
  val s=StringBuilder()
  n.text?.let{s.append(it).append(" ")}
  n.contentDescription?.let{s.append(it).append(" ")}
  for(i in 0 until n.childCount) n.getChild(i)?.let{s.append(collect(it))}
  return s.toString()
 }
 private fun showGuard(reason:String) {
  if(overlay!=null) return
  val layout=LinearLayout(this); layout.orientation=LinearLayout.VERTICAL; layout.gravity=Gravity.CENTER; layout.setPadding(48,48,48,48)
  val bg=GradientDrawable(); bg.setColor(Color.WHITE); bg.cornerRadius=32f; layout.background=bg
  val title=TextView(this); title.text="🛑  Rappelle-toi pourquoi"; title.textSize=24f; title.gravity=Gravity.CENTER
  val msg=TextView(this); msg.text=reason.ifBlank{"Tu avais choisi de ne pas contacter cette personne."}; msg.textSize=18f; msg.gravity=Gravity.CENTER; msg.setPadding(0,30,0,30)
  val back=Button(this); back.text="Retour"; back.setOnClickListener{performGlobalAction(GLOBAL_ACTION_BACK); removeGuard()}
  layout.addView(title); layout.addView(msg); layout.addView(back)
  val lp=WindowManager.LayoutParams(-1,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,-3)
  lp.gravity=Gravity.CENTER
  windowManager.addView(layout,lp); overlay=layout
 }
 private fun removeGuard(){ overlay?.let{windowManager.removeView(it)}; overlay=null }
 override fun onInterrupt(){ removeGuard() }
}